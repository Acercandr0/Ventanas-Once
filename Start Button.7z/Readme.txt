The config in the Windhawk Taskbar Styler Mod will look into "C:\Customization\Icons\Start Button" for this files.

You can copy the 3 .png o the same path, use your own .png, change the path in the mod settings or use URL instead.